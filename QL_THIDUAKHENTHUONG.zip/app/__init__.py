from flask import Flask, send_from_directory, session, redirect, url_for, flash
from flask_login import login_required, current_user, logout_user
from config import Config
from app.extensions import db, login_manager, csrf, migrate
import os


def create_app(config_class=None):
    app = Flask(__name__)
    app.config.from_object(config_class or Config)

    # Đảm bảo luôn dùng pymysql driver dù DATABASE_URL có prefix gì
    db_url = app.config.get('SQLALCHEMY_DATABASE_URI', '')
    if db_url.startswith('mysql://'):
        app.config['SQLALCHEMY_DATABASE_URI'] = db_url.replace('mysql://', 'mysql+pymysql://', 1)

    db.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)
    migrate.init_app(app, db)

    # Import models so they are registered
    from app import models  # noqa: F401

    # Register blueprints
    from app.routes.auth import auth_bp
    from app.routes.dashboard import dashboard_bp
    from app.routes.personnel import personnel_bp
    from app.routes.nomination import nomination_bp
    from app.routes.approval import approval_bp
    from app.routes.admin import admin_bp
    from app.routes.hoi_dong import hoi_dong_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(personnel_bp, url_prefix='/personnel')
    app.register_blueprint(nomination_bp, url_prefix='/nomination')
    app.register_blueprint(approval_bp, url_prefix='/approval')
    app.register_blueprint(admin_bp, url_prefix='/admin')
    app.register_blueprint(hoi_dong_bp, url_prefix='/hoi-dong')

    @app.before_request
    def enforce_single_session():
        """Force logout if session token doesn't match DB (another device logged in)."""
        if current_user.is_authenticated:
            stored = session.get('_session_token')
            if stored is None or current_user.session_token != stored:
                logout_user()
                session.clear()
                flash('Tài khoản đã được đăng nhập từ thiết bị khác. Vui lòng đăng nhập lại.', 'warning')
                return redirect(url_for('auth.login'))

    @app.route('/uploads/<path:filename>')
    @login_required
    def uploaded_file(filename):
        import os as _os
        full_path = _os.path.join(app.config['UPLOAD_FOLDER'], filename)
        if not _os.path.isfile(full_path):
            # Return a friendly SVG placeholder instead of 404 HTML
            ext = filename.rsplit('.', 1)[-1].lower() if '.' in filename else ''
            if ext in ('png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp'):
                svg = (
                    '<svg xmlns="http://www.w3.org/2000/svg" width="200" height="150">'
                    '<rect width="200" height="150" fill="#f8f9fa" stroke="#dee2e6" stroke-width="2" rx="6"/>'
                    '<text x="100" y="70" font-family="sans-serif" font-size="13" fill="#adb5bd" text-anchor="middle">Không tìm thấy ảnh</text>'
                    '<text x="100" y="90" font-family="sans-serif" font-size="11" fill="#ced4da" text-anchor="middle">(File không tồn tại)</text>'
                    '</svg>'
                )
                from flask import Response
                return Response(svg, status=200, mimetype='image/svg+xml')
            from flask import abort
            abort(404)
        return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

    @app.errorhandler(403)
    def forbidden(e):
        return '<h1>403 - Không có quyền truy cập</h1><a href="/">Về trang chủ</a>', 403

    @app.errorhandler(404)
    def not_found(e):
        return '<h1>404 - Không tìm thấy trang</h1><a href="/">Về trang chủ</a>', 404

    @app.teardown_request
    def teardown_request_handler(exception):
        if exception:
            try:
                db.session.rollback()
            except Exception:
                pass

    @app.context_processor
    def inject_notification_count():
        from flask_login import current_user
        count = 0
        pending_transfers = 0
        dept_pending_count = 0
        admin_pending_count = 0
        if current_user.is_authenticated:
            if current_user.is_unit_user:
                from app.models.notification import ThongBao
                from app.models.transfer import ChuyenDonVi, TrangThaiChuyen
                count = ThongBao.query.filter_by(
                    user_id=current_user.id, da_doc=False
                ).count()
                if current_user.don_vi_id:
                    pending_transfers = ChuyenDonVi.query.filter_by(
                        don_vi_dich_id=current_user.don_vi_id,
                        trang_thai=TrangThaiChuyen.PENDING,
                    ).count()
            if current_user.is_department:
                # Count PheDuyet records assigned to this dept user's role, not yet reviewed
                try:
                    from app.models.approval import PheDuyet, KetQuaDuyet
                    from app.routes.approval import ROLE_TO_PHONG
                    user_role = current_user.role.value if hasattr(current_user.role, 'value') else str(current_user.role)
                    phong = ROLE_TO_PHONG.get(current_user.role)
                    if phong:
                        dept_pending_count = PheDuyet.query.filter_by(
                            phong_duyet=phong, ket_qua=KetQuaDuyet.CHO_DUYET.value
                        ).count()
                except Exception:
                    dept_pending_count = 0
            if current_user.is_admin:
                # Count nominations not yet final-approved or rejected
                try:
                    from app.models.nomination import DeXuat, TrangThaiDeXuat
                    admin_pending_count = DeXuat.query.filter(
                        DeXuat.trang_thai.notin_([
                            TrangThaiDeXuat.PHE_DUYET_CUOI.value,
                            TrangThaiDeXuat.TU_CHOI.value,
                            TrangThaiDeXuat.NHAP.value,
                        ])
                    ).count()
                except Exception:
                    admin_pending_count = 0
        return dict(
            unread_notification_count=count,
            pending_transfer_count=pending_transfers,
            dept_pending_count=dept_pending_count,
            admin_pending_count=admin_pending_count,
        )

    # Jinja2 filter: clean ngay_nhap_ngu display (strip datetime noise)
    import re as _re
    from datetime import datetime as _dt

    @app.template_filter('clean_nhap_ngu')
    def clean_nhap_ngu_filter(value):
        if not value:
            return ''
        text = str(value).strip()
        if _re.match(r'^\d{2}/\d{4}$', text):
            return text
        for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d'):
            try:
                return _dt.strptime(text, fmt).strftime('%m/%Y')
            except ValueError:
                continue
        if ' ' in text:
            text = text.split(' ')[0]
        return text

    return app
